#ifndef CLIENT_H
#define CLIENT_H
#include "Cart.h"

class Client
{
public:
	Client();
	Client(const Client& other);
	Client& operator=(const Client& other);
	~Client();

	char* getName() const;
	double getBalance() const;
	const Cart& getCart() const;

	void printClientInfo() const;
	void printCartProducts() const;

private:
	void setName(const char* name);
	void setBalance(const double balance);
	void setCart(const Cart& cart);

	char* _name;
	double _balance;
	Cart _cart;
	

};

#endif // CLIENT_H