#ifndef PRODUCT_H
#define PRODUCT_H
#include <iostream>
#include <cstring>

/*
To Be Main Abstract Base Class
*/
class Product
{
public:
	Product();
	Product(const double price, const double weight);
	Product(const Product& other);
	Product& operator=(const Product& other);
	virtual ~Product();

	char* getDescription() const;
	double getPrice() const;
	double getWeight() const;

	void printInfo() const;

protected:
	void setDescription(const char* description);
	void setPrice(const double price);
	void setWeight(const double weight);

private:
	char* _description;
	double _price;
	double _weight;

};

#endif // PRODUCT_H