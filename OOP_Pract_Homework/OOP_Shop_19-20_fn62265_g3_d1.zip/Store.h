#ifndef STORE_H
#define STORE_H
#include "Product.h"

class Store
{
public:
	Store();
	Store(const Store& other);
	Store& operator=(const Store& other);
	~Store();

private:
	Product* _products;
	unsigned int _size;
	unsigned int _cap;

	unsigned int getSize() const;
	unsigned int getCap() const;

	void resize();
	void incrementSize();
};

#endif // STORE_H