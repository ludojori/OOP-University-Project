#ifndef CART_H
#define CART_H
#include "Product.h"

class Cart
{
public:
	Cart();
	Cart(const Cart& other);
	Cart& operator=(const Cart& other);
	~Cart();

	Cart& operator+(const Product& product);

	void addProduct(const Product& product);
	void printProducts() const;
	void clear();
	bool isEmpty() const;

private:
	Product* _products;
	unsigned int _size;
	unsigned int _cap;

	unsigned int getSize() const;
	unsigned int getCap() const;

	void resize();
	void incrementSize();

};

#endif // CART_H