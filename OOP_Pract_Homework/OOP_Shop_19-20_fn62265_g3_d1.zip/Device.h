#ifndef DEVICE_H
#define DEVICE_H

/*
To Inherit Class Product
*/
class Device
{
public:
	Device();
	Device(const char* brand, const char* model, const char* manufactorer);
	Device(const Device& other);
	Device& operator=(const Device& other);
	~Device();

	char* getBrand() const;
	char* getModel() const;
	char* getManufacturer() const;

	void printInfo() const;

protected:
	void setBrand(const char* brand);
	void setModel(const char* model);
	void setManufacturer(const char* manufactorer);

private:
	char* _brand;
	char* _model;
	char* _manufacturer;

};

#endif // DEVICE_H