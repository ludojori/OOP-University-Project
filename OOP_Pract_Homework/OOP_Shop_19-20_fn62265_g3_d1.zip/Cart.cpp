#include "Cart.h"

Cart::Cart()
{
	_size = 0;
	_cap = 1;
	_products = new Product[_cap];
}

Cart::Cart(const Cart& other)
{
	_size = other.getSize();
	_cap = other.getCap();
	_products = new Product[_cap];
	for (unsigned int i = 0; i < _size; ++i)
	{
		_products[i] = other._products[i];
	}
}

Cart& Cart::operator=(const Cart& other)
{
	if (this != &other)
	{
		_size = other.getSize();
		_cap = other.getCap();
		if (_products != nullptr)
		{
			delete[] _products;
		}
		_products = new Product[_cap];
		for (unsigned int i = 0; i < _size; ++i)
		{
			_products[i] = other._products[i];
		}
	}
	return *this;
}

Cart::~Cart()
{
	if (_products != nullptr)
	{
		delete[] _products;
	}
}

Cart& Cart::operator+(const Product& product)
{
	addProduct(product);
	return *this;
}

void Cart::addProduct(const Product& product)
{
	if (_size == _cap)
	{
		resize();
	}
	_products[_size - 1] = product;
	incrementSize();
}

void Cart::printProducts() const
{
	for (unsigned int i = 0; i < _size; ++i)
	{
		_products[i].printInfo();
	}
}

void Cart::clear()
{
	if (_products != nullptr)
	{
		delete[] _products;
	}
	_products = new Product[_cap];
	_size = 0;
}

bool Cart::isEmpty() const
{
	return (_size == 0);
}

unsigned int Cart::getSize() const
{
	return _size;
}

unsigned int Cart::getCap() const
{
	return _cap;
}

void Cart::resize()
{
	_cap *= 2;
	Product* temp = new Product[_cap];
	for (unsigned int i = 0; i < _size; ++i)
	{
		temp[i] = _products[i];
	}
	delete[] _products;
	_products = temp;
}

void Cart::incrementSize()
{
	++_size;
}
