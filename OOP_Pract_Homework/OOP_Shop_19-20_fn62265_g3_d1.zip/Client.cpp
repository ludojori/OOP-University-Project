#include "Client.h"

Client::Client()
{
	setName("Default_Name");
	setBalance(0.0f);
	setCart(Cart());
}

Client::Client(const Client& other)
{
	setName(other.getName());
	setBalance(other.getBalance());
	setCart(other.getCart());
}

Client& Client::operator=(const Client& other)
{
	if (this != &other)
	{
		setName(other.getName());
		setBalance(other.getBalance());
		setCart(other.getCart());
	}
	return *this;
}

Client::~Client()
{
	if (_name != nullptr)
	{
		delete[] _name;
	}
}

char* Client::getName() const
{
	return _name;
}

double Client::getBalance() const
{
	return _balance;
}

const Cart& Client::getCart() const
{
	return _cart;
}

void Client::printClientInfo() const
{
	std::cout
		<< "--> Client Info\n"
		<< "Name: " << _name << "\n"
		<< "Balance: " << _balance << "\n";
}

void Client::printCartProducts() const
{
	_cart.printProducts();
}

void Client::setName(const char* name)
{
	if (_name != nullptr)
	{
		delete[] _name;
	}
	_name = new char[strlen(name) + 1];
	strcpy_s(_name, strlen(name) + 1, name);
}

void Client::setBalance(const double balance)
{
	_balance = balance;
}

void Client::setCart(const Cart& cart)
{
	_cart = cart;
}
