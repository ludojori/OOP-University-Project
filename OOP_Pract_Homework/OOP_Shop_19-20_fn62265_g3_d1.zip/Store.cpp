#include "Store.h"

Store::Store()
{
	_size = 0;
	_cap = 1;
	_products = new Product[_cap];
}

Store::Store(const Store& other)
{
	_size = other.getSize();
	_cap = other.getCap();
	_products = new Product[_cap];
	for (unsigned int i = 0; i < _size; ++i)
	{
		_products[i] = other._products[i];
	}
}

Store& Store::operator=(const Store& other)
{
	if (this != &other)
	{
		_size = other.getSize();
		_cap = other.getCap();
		if (_products != nullptr)
		{
			delete[] _products;
		}
		_products = new Product[_cap];
		for (unsigned int i = 0; i < _size; ++i)
		{
			_products[i] = other._products[i];
		}
	}
	return *this;
}

Store::~Store()
{
	if (_products != nullptr)
	{
		delete[] _products;
	}
}

unsigned int Store::getSize() const
{
	return _size;
}

unsigned int Store::getCap() const
{
	return _cap;
}

void Store::resize()
{
	_cap *= 2;
	Product* temp = new Product[_cap];
	for (unsigned int i = 0; i < _size; ++i)
	{
		temp[i] = _products[i];
	}
	delete[] _products;
	_products = temp;
}

void Store::incrementSize()
{
	++_size;
}
