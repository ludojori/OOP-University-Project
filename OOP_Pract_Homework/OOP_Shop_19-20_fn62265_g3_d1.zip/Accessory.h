#ifndef ACCESSORY_H
#define ACCESSORY_H

/*
To Inherit Class Product
*/
class Accessory
{
public:
	Accessory();
	Accessory(const Accessory& other);
	Accessory& operator=(const Accessory& other);
	~Accessory();

	char* getName() const;

	void printInfo() const;

protected:
	void setName(const char* name);

private:
	char* _name;

};

#endif // ACCESSORY_H